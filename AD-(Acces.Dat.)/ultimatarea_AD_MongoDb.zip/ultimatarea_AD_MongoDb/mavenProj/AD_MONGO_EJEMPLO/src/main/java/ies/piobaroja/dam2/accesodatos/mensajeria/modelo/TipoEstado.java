package ies.piobaroja.dam2.accesodatos.mensajeria.modelo;

public enum TipoEstado {
	EN_ESPERA,ASIGNADO, ENTREGADO
}

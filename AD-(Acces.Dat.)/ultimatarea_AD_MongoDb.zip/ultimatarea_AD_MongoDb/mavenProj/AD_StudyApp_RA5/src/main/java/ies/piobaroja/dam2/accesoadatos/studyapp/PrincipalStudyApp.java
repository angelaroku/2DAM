package ies.piobaroja.dam2.accesoadatos.studyapp;


public class PrincipalStudyApp {
	public static void main(String[] args) {
		MenuGenStudyApp menu = new MenuGenStudyApp();
		menu.setSize(600, 500);
		menu.setVisible(true);
	}
}

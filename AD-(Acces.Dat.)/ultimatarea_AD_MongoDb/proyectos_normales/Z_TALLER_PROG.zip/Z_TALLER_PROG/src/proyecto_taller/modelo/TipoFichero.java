package proyecto_taller.modelo;

public enum TipoFichero {
	FICHERO_EXPORTADO, FICHERO_IMPORTADO;

}

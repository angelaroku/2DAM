 package ies.piobaroja.dam2.accesodatos.mensajeria;

public class Principal {
	
	public static void main(String[] args) {
		Ventana ventana=new Ventana();
		ventana.setSize(400, 500);
		ventana.setVisible(true);
	}

}

var namespaces_dup =
[
    [ "App1SocialLink", "namespace_app1_social_link.html", "namespace_app1_social_link" ]
];
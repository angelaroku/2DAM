var dir_10b664426e58c6b08456ea457f24c0f3 =
[
    [ "Cosa1.xaml.cs", "_cosa1_8xaml_8cs.html", "_cosa1_8xaml_8cs" ],
    [ "NuevaCosa.xaml.cs", "_nueva_cosa_8xaml_8cs.html", "_nueva_cosa_8xaml_8cs" ],
    [ "OtraCosaMas.xaml.cs", "_otra_cosa_mas_8xaml_8cs.html", "_otra_cosa_mas_8xaml_8cs" ]
];
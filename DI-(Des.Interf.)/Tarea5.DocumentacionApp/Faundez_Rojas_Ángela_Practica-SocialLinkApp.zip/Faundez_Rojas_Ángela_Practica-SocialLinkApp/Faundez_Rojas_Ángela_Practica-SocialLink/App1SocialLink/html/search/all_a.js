var searchData=
[
  ['principalusuariopage_0',['PrincipalUsuarioPage',['../class_app1_social_link_1_1_principal_usuario_page.html',1,'App1SocialLink.PrincipalUsuarioPage'],['../class_app1_social_link_1_1_principal_usuario_page.html#a9406085c2721c6bc9103fbd48dd17a40',1,'App1SocialLink.PrincipalUsuarioPage.PrincipalUsuarioPage()']]],
  ['principalusuariopage_2eg_2ecs_1',['PrincipalUsuarioPage.g.cs',['../_principal_usuario_page_8g_8cs.html',1,'']]],
  ['principalusuariopage_2eg_2ei_2ecs_2',['PrincipalUsuarioPage.g.i.cs',['../_principal_usuario_page_8g_8i_8cs.html',1,'']]],
  ['principalusuariopage_2examl_2ecs_3',['PrincipalUsuarioPage.xaml.cs',['../_principal_usuario_page_8xaml_8cs.html',1,'']]]
];

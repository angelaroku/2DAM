var searchData=
[
  ['mainpage_0',['MainPage',['../class_app1_social_link_1_1_main_page.html#af607774731c2f7231469969754dcdd00',1,'App1SocialLink::MainPage']]]
];

var searchData=
[
  ['otracosamas_2eg_2ecs_0',['OtraCosaMas.g.cs',['../_otra_cosa_mas_8g_8cs.html',1,'']]],
  ['otracosamas_2eg_2ei_2ecs_1',['OtraCosaMas.g.i.cs',['../_otra_cosa_mas_8g_8i_8cs.html',1,'']]],
  ['otracosamas_2examl_2ecs_2',['OtraCosaMas.xaml.cs',['../_otra_cosa_mas_8xaml_8cs.html',1,'']]]
];

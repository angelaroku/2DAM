var searchData=
[
  ['app_0',['App',['../class_app1_social_link_1_1_app.html',1,'App1SocialLink']]]
];

var searchData=
[
  ['mainpage_2eg_2ecs_0',['MainPage.g.cs',['../_main_page_8g_8cs.html',1,'']]],
  ['mainpage_2eg_2ei_2ecs_1',['MainPage.g.i.cs',['../_main_page_8g_8i_8cs.html',1,'']]],
  ['mainpage_2examl_2ecs_2',['MainPage.xaml.cs',['../_main_page_8xaml_8cs.html',1,'']]]
];

var searchData=
[
  ['principalusuariopage_2eg_2ecs_0',['PrincipalUsuarioPage.g.cs',['../_principal_usuario_page_8g_8cs.html',1,'']]],
  ['principalusuariopage_2eg_2ei_2ecs_1',['PrincipalUsuarioPage.g.i.cs',['../_principal_usuario_page_8g_8i_8cs.html',1,'']]],
  ['principalusuariopage_2examl_2ecs_2',['PrincipalUsuarioPage.xaml.cs',['../_principal_usuario_page_8xaml_8cs.html',1,'']]]
];

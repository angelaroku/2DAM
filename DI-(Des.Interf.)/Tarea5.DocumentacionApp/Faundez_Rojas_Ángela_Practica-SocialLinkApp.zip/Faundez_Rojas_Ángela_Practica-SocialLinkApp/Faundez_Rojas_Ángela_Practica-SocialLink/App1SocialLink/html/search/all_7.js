var searchData=
[
  ['mainpage_0',['MainPage',['../class_app1_social_link_1_1_main_page.html',1,'App1SocialLink.MainPage'],['../class_app1_social_link_1_1_main_page.html#af607774731c2f7231469969754dcdd00',1,'App1SocialLink.MainPage.MainPage()']]],
  ['mainpage_2eg_2ecs_1',['MainPage.g.cs',['../_main_page_8g_8cs.html',1,'']]],
  ['mainpage_2eg_2ei_2ecs_2',['MainPage.g.i.cs',['../_main_page_8g_8i_8cs.html',1,'']]],
  ['mainpage_2examl_2ecs_3',['MainPage.xaml.cs',['../_main_page_8xaml_8cs.html',1,'']]]
];

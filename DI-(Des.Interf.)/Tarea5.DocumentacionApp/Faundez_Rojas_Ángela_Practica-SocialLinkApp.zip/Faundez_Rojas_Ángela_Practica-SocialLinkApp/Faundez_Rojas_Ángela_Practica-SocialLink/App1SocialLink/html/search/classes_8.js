var searchData=
[
  ['usuario_0',['Usuario',['../class_app1_social_link_1_1_models_1_1_usuario.html',1,'App1SocialLink::Models']]]
];

var searchData=
[
  ['nombre_0',['Nombre',['../class_app1_social_link_1_1_models_1_1_usuario.html#a3c262f9e069f3808cc413727e2596f4a',1,'App1SocialLink::Models::Usuario']]],
  ['nuevacosa_1',['NuevaCosa',['../class_app1_social_link_1_1_components_1_1_nueva_cosa.html',1,'App1SocialLink.Components.NuevaCosa'],['../class_app1_social_link_1_1_components_1_1_nueva_cosa.html#a9dd7028656dfc12027bf1952a1cbb294',1,'App1SocialLink.Components.NuevaCosa.NuevaCosa()']]],
  ['nuevacosa_2eg_2ecs_2',['NuevaCosa.g.cs',['../_nueva_cosa_8g_8cs.html',1,'']]],
  ['nuevacosa_2eg_2ei_2ecs_3',['NuevaCosa.g.i.cs',['../_nueva_cosa_8g_8i_8cs.html',1,'']]],
  ['nuevacosa_2examl_2ecs_4',['NuevaCosa.xaml.cs',['../_nueva_cosa_8xaml_8cs.html',1,'']]]
];

var searchData=
[
  ['nombre_0',['Nombre',['../class_app1_social_link_1_1_models_1_1_usuario.html#a3c262f9e069f3808cc413727e2596f4a',1,'App1SocialLink::Models::Usuario']]]
];

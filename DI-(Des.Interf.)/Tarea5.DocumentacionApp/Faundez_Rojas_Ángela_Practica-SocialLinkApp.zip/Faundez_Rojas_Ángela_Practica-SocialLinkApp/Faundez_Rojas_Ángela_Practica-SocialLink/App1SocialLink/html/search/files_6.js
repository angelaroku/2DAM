var searchData=
[
  ['nuevacosa_2eg_2ecs_0',['NuevaCosa.g.cs',['../_nueva_cosa_8g_8cs.html',1,'']]],
  ['nuevacosa_2eg_2ei_2ecs_1',['NuevaCosa.g.i.cs',['../_nueva_cosa_8g_8i_8cs.html',1,'']]],
  ['nuevacosa_2examl_2ecs_2',['NuevaCosa.xaml.cs',['../_nueva_cosa_8xaml_8cs.html',1,'']]]
];

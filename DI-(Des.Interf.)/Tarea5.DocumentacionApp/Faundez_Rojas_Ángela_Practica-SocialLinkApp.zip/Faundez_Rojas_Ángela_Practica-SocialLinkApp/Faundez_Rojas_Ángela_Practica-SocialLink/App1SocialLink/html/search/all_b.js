var searchData=
[
  ['usuario_0',['Usuario',['../class_app1_social_link_1_1_models_1_1_usuario.html',1,'App1SocialLink::Models']]],
  ['usuario_2ecs_1',['Usuario.cs',['../_usuario_8cs.html',1,'']]]
];

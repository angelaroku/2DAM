var searchData=
[
  ['blankpage2_2examl_2ecs_0',['BlankPage2.xaml.cs',['../_blank_page2_8xaml_8cs.html',1,'']]]
];

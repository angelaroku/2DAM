var searchData=
[
  ['blankpage2_0',['BlankPage2',['../class_app1_social_link_1_1_blank_page2.html#a758980c8fbb828e135eceb67194e8ffc',1,'App1SocialLink::BlankPage2']]]
];

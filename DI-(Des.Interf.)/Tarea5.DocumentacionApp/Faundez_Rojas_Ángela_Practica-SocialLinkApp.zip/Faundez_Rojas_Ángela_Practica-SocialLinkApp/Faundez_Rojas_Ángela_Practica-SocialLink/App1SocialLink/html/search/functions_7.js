var searchData=
[
  ['nuevacosa_0',['NuevaCosa',['../class_app1_social_link_1_1_components_1_1_nueva_cosa.html#a9dd7028656dfc12027bf1952a1cbb294',1,'App1SocialLink::Components::NuevaCosa']]]
];

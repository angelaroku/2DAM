var searchData=
[
  ['principalusuariopage_0',['PrincipalUsuarioPage',['../class_app1_social_link_1_1_principal_usuario_page.html#a9406085c2721c6bc9103fbd48dd17a40',1,'App1SocialLink::PrincipalUsuarioPage']]]
];

var class_app1_social_link_1_1_components_1_1_nueva_cosa =
[
    [ "NuevaCosa", "class_app1_social_link_1_1_components_1_1_nueva_cosa.html#a9dd7028656dfc12027bf1952a1cbb294", null ],
    [ "Connect", "class_app1_social_link_1_1_components_1_1_nueva_cosa.html#a36b4a2fc4d88832c8161a0270df9e0a3", null ],
    [ "GetBindingConnector", "class_app1_social_link_1_1_components_1_1_nueva_cosa.html#ab9e874b4581ff70145c01a24d2c2aa6c", null ],
    [ "InitializeComponent", "class_app1_social_link_1_1_components_1_1_nueva_cosa.html#a553febc6079538d3d3b39ed5873ac6fb", null ],
    [ "csBackgroundColor", "class_app1_social_link_1_1_components_1_1_nueva_cosa.html#a22360138e788044280596497baa9fed6", null ],
    [ "csNuevoIconoNuevaCosa", "class_app1_social_link_1_1_components_1_1_nueva_cosa.html#a160eb0bffbee4f22b8767ee129e267c6", null ],
    [ "csTextoDeMiNuevaCosa", "class_app1_social_link_1_1_components_1_1_nueva_cosa.html#a0539104eb68619d2330f30d394dfcbaa", null ]
];
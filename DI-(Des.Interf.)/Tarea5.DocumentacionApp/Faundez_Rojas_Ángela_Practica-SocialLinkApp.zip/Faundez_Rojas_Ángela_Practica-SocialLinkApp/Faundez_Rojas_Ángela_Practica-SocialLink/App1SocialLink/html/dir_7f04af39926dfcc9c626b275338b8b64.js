var dir_7f04af39926dfcc9c626b275338b8b64 =
[
    [ "ComunidadSinUsuarioPage.xaml.cs", "_comunidad_sin_usuario_page_8xaml_8cs.html", "_comunidad_sin_usuario_page_8xaml_8cs" ],
    [ "CrearNuevoUsuarioPage.xaml.cs", "_crear_nuevo_usuario_page_8xaml_8cs.html", "_crear_nuevo_usuario_page_8xaml_8cs" ],
    [ "EntradaConUsuarioPage.xaml.cs", "_entrada_con_usuario_page_8xaml_8cs.html", "_entrada_con_usuario_page_8xaml_8cs" ],
    [ "EntradaSinUsuarioPage.xaml.cs", "_entrada_sin_usuario_page_8xaml_8cs.html", "_entrada_sin_usuario_page_8xaml_8cs" ],
    [ "MainPage.xaml.cs", "_main_page_8xaml_8cs.html", "_main_page_8xaml_8cs" ],
    [ "PrincipalUsuarioPage.xaml.cs", "_principal_usuario_page_8xaml_8cs.html", "_principal_usuario_page_8xaml_8cs" ]
];
var class_app1_social_link_1_1_app =
[
    [ "App", "class_app1_social_link_1_1_app.html#ad8ecbc7fd1e0d8047878768c58ff5c32", null ],
    [ "GetXamlType", "class_app1_social_link_1_1_app.html#a7ed2a45bde5777e09e28df712cfcf114", null ],
    [ "GetXamlType", "class_app1_social_link_1_1_app.html#ae8d70cab30bb8c74cc20c09ed3dca746", null ],
    [ "GetXmlnsDefinitions", "class_app1_social_link_1_1_app.html#ae7856a7cf05cbf71739f5bc02cb7be1b", null ],
    [ "InitializeComponent", "class_app1_social_link_1_1_app.html#a4b601dd34b4ddaff0ce626a53f704e21", null ],
    [ "OnLaunched", "class_app1_social_link_1_1_app.html#a6d5edc585de03661e90906e05eb2691a", null ]
];
var class_app1_social_link_1_1_models_1_1_usuario =
[
    [ "Contrase�a", "class_app1_social_link_1_1_models_1_1_usuario.html#a95fc54ad94d732a9085b4af12d88b2d9", null ],
    [ "Email", "class_app1_social_link_1_1_models_1_1_usuario.html#ace1de94b72868f09e9cbc6964f9ffb4d", null ],
    [ "Id", "class_app1_social_link_1_1_models_1_1_usuario.html#aec4dff85a624de533437aa29d767feb6", null ],
    [ "Nombre", "class_app1_social_link_1_1_models_1_1_usuario.html#a3c262f9e069f3808cc413727e2596f4a", null ]
];
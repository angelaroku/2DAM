var _cosa1_8xaml_8cs =
[
    [ "App1SocialLink.Components.Cosa1", "class_app1_social_link_1_1_components_1_1_cosa1.html", "class_app1_social_link_1_1_components_1_1_cosa1" ]
];
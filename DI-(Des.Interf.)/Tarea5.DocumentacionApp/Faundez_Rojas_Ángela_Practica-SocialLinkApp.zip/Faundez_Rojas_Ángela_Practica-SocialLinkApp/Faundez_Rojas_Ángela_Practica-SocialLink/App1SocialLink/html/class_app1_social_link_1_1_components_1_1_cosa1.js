var class_app1_social_link_1_1_components_1_1_cosa1 =
[
    [ "Cosa1", "class_app1_social_link_1_1_components_1_1_cosa1.html#aba2f90c6fbc8cf25976866046b67b54f", null ],
    [ "Connect", "class_app1_social_link_1_1_components_1_1_cosa1.html#a9f2872df94a2c1d94eab8725249c73fe", null ],
    [ "GetBindingConnector", "class_app1_social_link_1_1_components_1_1_cosa1.html#a9d15f04643264dd3039464a5a2497e6a", null ],
    [ "InitializeComponent", "class_app1_social_link_1_1_components_1_1_cosa1.html#a1a9eb6e5d5ed6be433f81e0c01eb289f", null ],
    [ "csdescripcion", "class_app1_social_link_1_1_components_1_1_cosa1.html#a246183cb4517b834ebc2a5cb66f53526", null ],
    [ "csnombre", "class_app1_social_link_1_1_components_1_1_cosa1.html#a47f13da28f377027220d5c44fd3540a8", null ],
    [ "csprecio", "class_app1_social_link_1_1_components_1_1_cosa1.html#a80c0a8213c5cbb1b87679331d888668e", null ]
];
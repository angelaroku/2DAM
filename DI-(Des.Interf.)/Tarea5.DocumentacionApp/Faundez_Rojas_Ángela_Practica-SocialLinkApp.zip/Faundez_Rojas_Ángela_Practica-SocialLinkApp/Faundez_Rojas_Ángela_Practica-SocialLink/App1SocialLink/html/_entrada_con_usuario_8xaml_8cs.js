var _entrada_con_usuario_8xaml_8cs =
[
    [ "App1SocialLink.EntradaConUsuario", "class_app1_social_link_1_1_entrada_con_usuario.html", "class_app1_social_link_1_1_entrada_con_usuario" ]
];
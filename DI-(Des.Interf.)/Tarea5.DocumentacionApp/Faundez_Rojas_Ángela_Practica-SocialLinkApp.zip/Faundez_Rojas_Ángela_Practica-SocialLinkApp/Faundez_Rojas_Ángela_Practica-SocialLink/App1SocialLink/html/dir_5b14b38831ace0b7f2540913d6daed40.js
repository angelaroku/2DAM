var dir_5b14b38831ace0b7f2540913d6daed40 =
[
    [ "Components", "dir_62aff6863a7a53984047b5a158dc1f63.html", "dir_62aff6863a7a53984047b5a158dc1f63" ],
    [ "Views", "dir_a03469a1a003f195b393a5fe1f12f049.html", "dir_a03469a1a003f195b393a5fe1f12f049" ],
    [ ".NETCore,Version=v5.0.AssemblyAttributes.cs", "_8_n_e_t_core_00_version_0av5_80_8_assembly_attributes_8cs.html", null ],
    [ "App.g.cs", "_app_8g_8cs.html", "_app_8g_8cs" ],
    [ "App.g.i.cs", "_app_8g_8i_8cs.html", "_app_8g_8i_8cs" ],
    [ "XamlTypeInfo.g.cs", "_xaml_type_info_8g_8cs.html", "_xaml_type_info_8g_8cs" ]
];
var _xaml_type_info_8g_8cs =
[
    [ "App1SocialLink.App", "class_app1_social_link_1_1_app.html", "class_app1_social_link_1_1_app" ],
    [ "App1SocialLink.App1SocialLink_XamlTypeInfo.XamlMetaDataProvider", "class_app1_social_link_1_1_app1_social_link___xaml_type_info_1_1_xaml_meta_data_provider.html", "class_app1_social_link_1_1_app1_social_link___xaml_type_info_1_1_xaml_meta_data_provider" ]
];
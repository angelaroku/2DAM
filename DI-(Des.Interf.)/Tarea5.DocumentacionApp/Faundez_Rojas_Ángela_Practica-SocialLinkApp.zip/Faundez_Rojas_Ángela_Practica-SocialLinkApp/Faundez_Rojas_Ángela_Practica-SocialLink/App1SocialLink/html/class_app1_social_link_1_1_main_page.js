var class_app1_social_link_1_1_main_page =
[
    [ "MainPage", "class_app1_social_link_1_1_main_page.html#af607774731c2f7231469969754dcdd00", null ],
    [ "Connect", "class_app1_social_link_1_1_main_page.html#a111c67328f201a3a873d31673ad5a1f8", null ],
    [ "GetBindingConnector", "class_app1_social_link_1_1_main_page.html#ae5b7d7dbddee252aa0fa975ec605db41", null ],
    [ "InitializeComponent", "class_app1_social_link_1_1_main_page.html#a99210a6e408b6ea9a28e201bc66fc49f", null ]
];
var _blank_page2_8xaml_8cs =
[
    [ "App1SocialLink.BlankPage2", "class_app1_social_link_1_1_blank_page2.html", "class_app1_social_link_1_1_blank_page2" ]
];
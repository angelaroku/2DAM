var class_app1_social_link_1_1_app1_social_link___xaml_type_info_1_1_xaml_meta_data_provider =
[
    [ "GetXamlType", "class_app1_social_link_1_1_app1_social_link___xaml_type_info_1_1_xaml_meta_data_provider.html#a95661084096800c8c4497985faec13b2", null ],
    [ "GetXamlType", "class_app1_social_link_1_1_app1_social_link___xaml_type_info_1_1_xaml_meta_data_provider.html#aaa6203de3c710d189b8219fef2be3642", null ],
    [ "GetXmlnsDefinitions", "class_app1_social_link_1_1_app1_social_link___xaml_type_info_1_1_xaml_meta_data_provider.html#a15dad23736e0371e3c005512ff0f8ddf", null ]
];
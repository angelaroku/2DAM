var class_app1_social_link_1_1_principal_usuario_page =
[
    [ "PrincipalUsuarioPage", "class_app1_social_link_1_1_principal_usuario_page.html#a9406085c2721c6bc9103fbd48dd17a40", null ],
    [ "Connect", "class_app1_social_link_1_1_principal_usuario_page.html#a77c44a5862aa61cc346a817be868f918", null ],
    [ "GetBindingConnector", "class_app1_social_link_1_1_principal_usuario_page.html#ace7f4de6a43b9f41cf3222103a3860dc", null ],
    [ "InitializeComponent", "class_app1_social_link_1_1_principal_usuario_page.html#a0172dcf53018bc937297b5c2af177be4", null ]
];
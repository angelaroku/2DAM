using Windows.UI.Xaml.Controls;

// La plantilla de elemento P�gina en blanco est� documentada en https://go.microsoft.com/fwlink/?LinkId=234238

namespace App1SocialLink
{
    /// <summary>
    /// Pagina principal despues de acceder con usuario.
    /// </summary>
    public sealed partial class PrincipalUsuarioPage : Page
    {
        public PrincipalUsuarioPage()
        {
            this.InitializeComponent();
        }


    }
}
